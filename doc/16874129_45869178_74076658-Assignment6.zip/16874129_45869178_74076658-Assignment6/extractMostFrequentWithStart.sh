#!/bin/bash

directory=$1

mkdir $directory/tmp


cat $directory/part-r-* > $directory/tmp/complete

grep ^$4 -i $directory/tmp/complete > $directory/tmp/filtered

sort -k$2 -n -r $directory/tmp/filtered > $directory/tmp/sorted

head -$3 $directory/tmp/sorted

rm -r $directory/tmp
